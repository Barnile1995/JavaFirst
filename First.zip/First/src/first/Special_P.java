/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package first;

/**
 *
 * @author Barnile Diganta
 */
public class Special_P extends First_P {
    
   private String date_of_birth;
   
   public String getdate_of_birth() {
      return date_of_birth;
   }
   
    public void setdate_of_birth(String newdate_of_birth) {
      date_of_birth = newdate_of_birth;
   }
   }
    

