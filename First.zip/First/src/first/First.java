/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package first;

/**
 *
 * @author Barnile Diganta
 */
public class First {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      
      First_P encap = new First_P(); 
      encap.setName("Barnile");
      encap.setAge(23);
      encap.setIdNum("15-28492-1");
      System.out.print("Name : " + encap.getName() + " Age : " + encap.getAge() 
              + " ID : " + encap.getIdNum() + "\n");
      Special_P person = new Special_P();
      person.setdate_of_birth("14.5.1990");
      System.out.print("Date of birth : " + person.getdate_of_birth());
    
    }
    
}
